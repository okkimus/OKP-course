package com.vaadin;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NaytosRepository extends JpaRepository<Naytos, Long> {
}
