package com.vaadin;

public interface ElokuvaChangeListener {
    void ElokuvaChanged(Elokuva elokuva);
}
