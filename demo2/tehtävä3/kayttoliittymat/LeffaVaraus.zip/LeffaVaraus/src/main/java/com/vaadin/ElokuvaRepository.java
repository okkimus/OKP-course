package com.vaadin;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ElokuvaRepository extends JpaRepository<Elokuva, Long>{
}
